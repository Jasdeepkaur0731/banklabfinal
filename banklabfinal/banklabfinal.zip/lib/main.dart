import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:animated_text_kit/animated_text_kit.dart';

void main() {
  runApp(AxisBankApp());
}

class AxisBankApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Axis Bank App',
      theme: ThemeData(
        primarySwatch: Colors.red,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      debugShowCheckedModeBanner: false,
      home: SignUpPage(),
    );
  }
}

class User {
  final String email;
  final String password;

  User({required this.email, required this.password});
}

class SignUpPage extends StatefulWidget {
  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();

  static List<User> users = [];

  void _signUp() {
    String email = emailController.text;
    String password = passwordController.text;
    String confirmPassword = confirmPasswordController.text;

    if (password != confirmPassword) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Passwords do not match')),
      );
      return;
    }

    users.add(User(email: email, password: password));

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Sign up successful')),
    );

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => LoginPage(users: users)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Sign Up')),
      backgroundColor: Colors.grey[100],
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              'assets/images/axisbank_logo.png',
              width: 150,
              height: 150,
            ),
            SizedBox(height: 20),
            AnimatedTextKit(
              animatedTexts: [
                TypewriterAnimatedText(
                  'Welcome to Axis Bank',
                  textStyle: TextStyle(
                    fontSize: 32.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.red[800],
                  ),
                  speed: Duration(milliseconds: 200),
                ),
              ],
              totalRepeatCount: 1,
              pause: Duration(milliseconds: 500),
              displayFullTextOnTap: true,
              stopPauseOnTap: true,
            ),
            SizedBox(height: 10),
            Text(
              'Today\'s date: ${DateTime.now().toLocal().toString().split(' ')[0]}',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(
                labelText: 'Password',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),
            SizedBox(height: 20),
            TextField(
              controller: confirmPasswordController,
              decoration: InputDecoration(
                labelText: 'Confirm Password',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _signUp,
              child: Text('Sign Up'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red[800],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  final List<User> users;

  LoginPage({required this.users});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  void _login() {
    String email = emailController.text;
    String password = passwordController.text;

    bool isUserValid = widget.users.any((user) =>
    user.email == email && user.password == password);

    if (isUserValid) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => HomePage(email: email)),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Invalid credentials')),
      );
    }
  }

  void _forgotPassword() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Forgot Password functionality not implemented yet.')),
    );
  }

  void _help() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Help functionality not implemented yet.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              'assets/images/axisbank_logo.png',
              width: 150,
              height: 150,
            ),
            SizedBox(height: 20),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(
                labelText: 'Password',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _login,
              child: Text('Login'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red[800],
              ),
            ),
            TextButton(
              onPressed: _forgotPassword,
              child: Text('Forgot Password?'),
            ),
            TextButton(
              onPressed: _help,
              child: Text('Help'),
            ),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final String email;

  HomePage({required this.email});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController transferAmountController = TextEditingController();
  final TextEditingController recipientAccountController = TextEditingController();
  String selectedFromAccount = "chequing";
  String selectedToAccount = "savings";
  bool isSendingMoney = false;
  final PageController _pageController = PageController();
  int _currentPage = 0;
  late Timer _timer;

  Map<String, dynamic>? accountData;
  String? errorMessage;

  // Define the transactions list
  List<Map<String, dynamic>> transactions = [];

  @override
  void initState() {
    super.initState();
    _startAutoSlide();
    fetchAccountData();
  }

  Future<void> fetchAccountData() async {
    try {
      final response = await http.get(Uri.parse('http://nawazchowdhury.com/acc.php'));

      if (response.statusCode == 200) {
        setState(() {
          accountData = json.decode(response.body);
          errorMessage = null;
        });
      } else {
        setState(() {
          errorMessage = 'Failed to load data: ${response.statusCode}';
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = 'Error: $e';
      });
    }
  }

  @override
  void dispose() {
    _timer.cancel();
    _pageController.dispose();
    super.dispose();
  }

  void _startAutoSlide() {
    _timer = Timer.periodic(Duration(seconds: 3), (Timer timer) {
      if (_currentPage < 2) {
        _currentPage++;
      } else {
        _currentPage = 0;
      }

      _pageController.animateToPage(
        _currentPage,
        duration: Duration(milliseconds: 300),
        curve: Curves.easeIn,
      );
    });
  }

  String _getCurrentDateTime() {
    DateTime now = DateTime.now();
    return "${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')} ${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}";
  }

  void _transferMoney() {
    double amount = double.tryParse(transferAmountController.text) ?? 0;

    if (amount > 0) {
      setState(() {
        if (selectedFromAccount == "chequing" && selectedToAccount == "savings" && accountData!["chequing"]["balance"] >= amount) {
          accountData!["chequing"]["balance"] -= amount;
          accountData!["savings"]["balance"] += amount;
        } else if (selectedFromAccount == "savings" && selectedToAccount == "chequing" && accountData!["savings"]["balance"] >= amount) {
          accountData!["savings"]["balance"] -= amount;
          accountData!["chequing"]["balance"] += amount;
        }

        transactions.add({
          "fromAccount": selectedFromAccount,
          "toAccount": selectedToAccount,
          "amount": amount,
          "date": _getCurrentDateTime(),
          "recipientAccount": ""
        });

        transferAmountController.clear();
        recipientAccountController.clear();
      });
    }
  }

  void _sendMoney() {
    double amount = double.tryParse(transferAmountController.text) ?? 0;

    if (amount > 0 && recipientAccountController.text.isNotEmpty) {
      setState(() {
        if (selectedFromAccount == "chequing" && accountData!["chequing"]["balance"] >= amount) {
          accountData!["chequing"]["balance"] -= amount;
        } else if (selectedFromAccount == "savings" && accountData!["savings"]["balance"] >= amount) {
          accountData!["savings"]["balance"] -= amount;
        }

        transactions.add({
          "fromAccount": selectedFromAccount,
          "toAccount": "external",
          "amount": amount,
          "date": _getCurrentDateTime(),
          "recipientAccount": recipientAccountController.text
        });

        transferAmountController.clear();
        recipientAccountController.clear();
      });
    }
  }

  Widget _buildTransferOptions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            ElevatedButton(
              onPressed: () {
                setState(() {
                  isSendingMoney = false;
                });
              },
              child: Text('Transfer Between Accounts'),
              style: ElevatedButton.styleFrom(
                backgroundColor: isSendingMoney ? Colors.grey : Colors.red[800],
              ),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  isSendingMoney = true;
                });
              },
              child: Text('Send Money to Someone'),
              style: ElevatedButton.styleFrom(
                backgroundColor: isSendingMoney ? Colors.red[800] : Colors.grey,
              ),
            ),
          ],
        ),
        SizedBox(height: 20),
        Text(isSendingMoney ? 'Send Money' : 'Transfer Between Accounts',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        if (!isSendingMoney) ...[
          DropdownButton<String>(
            value: selectedFromAccount,
            onChanged: (String? newValue) {
              setState(() {
                selectedFromAccount = newValue!;
                selectedToAccount = selectedFromAccount == "chequing" ? "savings" : "chequing";
              });
            },
            items: <String>['chequing', 'savings']
                .map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text('${value[0].toUpperCase()}${value.substring(1)} (Balance: \$${accountData![value]['balance']})'),
              );
            }).toList(),
          ),
          DropdownButton<String>(
            value: selectedToAccount,
            onChanged: (String? newValue) {
              setState(() {
                selectedToAccount = newValue!;
              });
            },
            items: <String>['chequing', 'savings']
                .map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text('${value[0].toUpperCase()}${value.substring(1)} (Balance: \$${accountData![value]['balance']})'),
              );
            }).toList(),
          ),
        ],
        if (isSendingMoney) ...[
          DropdownButton<String>(
            value: selectedFromAccount,
            onChanged: (String? newValue) {
              setState(() {
                selectedFromAccount = newValue!;
              });
            },
            items: <String>['chequing', 'savings']
                .map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text('${value[0].toUpperCase()}${value.substring(1)} (Balance: \$${accountData![value]['balance']})'),
              );
            }).toList(),
          ),
          TextField(
            controller: recipientAccountController,
            decoration: InputDecoration(labelText: 'Recipient Account Number'),
          ),
        ],
        TextField(
          controller: transferAmountController,
          decoration: InputDecoration(labelText: 'Amount'),
          keyboardType: TextInputType.number,
        ),
        SizedBox(height: 10),
        ElevatedButton(
          onPressed: isSendingMoney ? _sendMoney : _transferMoney,
          child: Text(isSendingMoney ? 'Send Money' : 'Transfer Between Accounts'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red[800],
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Axis Bank'),
        actions: [
          IconButton(
            icon: Icon(Icons.help_outline),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Help functionality not implemented yet.')),
              );
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.red[800],
              ),
              child: Text(
                'Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.account_balance),
              title: Text('Accounts'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AccountsPage(accountData: accountData)),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.attach_money),
              title: Text('Loans'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LoansPage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.credit_card),
              title: Text('Cards'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CardsPage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.person),
              title: Text('Profile'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ProfilePage(email: widget.email)),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text('Logout'),
              onTap: () {
                Navigator.popUntil(context, (route) => route.isFirst);
              },
            ),
          ],
        ),
      ),
      body: errorMessage != null
          ? Center(child: Text(errorMessage!))
          : accountData == null
          ? Center(child: CircularProgressIndicator())
          : ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          buildImageSlider(),
          buildFeatureGrid(),
          _buildTransferOptions(),
          buildTransactionTable(),
          buildFooter(context),
        ],
      ),
    );
  }

  Widget buildImageSlider() {
    return Container(
      height: 200,
      child: PageView.builder(
        controller: _pageController,
        itemCount: 3,
        itemBuilder: (context, index) {
          return Image.asset(
            'assets/images/banner${index + 1}.jpg',
            width: double.infinity,
            height: 200,
            fit: BoxFit.cover,
          );
        },
      ),
    );
  }

  Widget buildFeatureGrid() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        children: <Widget>[
          buildFeatureBox(Icons.calculate, 'EMI Calculator'),
          buildFeatureBox(Icons.calculate, 'SIP Calculator'),
          buildFeatureBox(Icons.calculate, 'Fixed Deposit Calculator'),
          buildFeatureBox(Icons.book, 'How to Create a Saving Account?'),
          buildFeatureBox(Icons.help, 'Why This Bank?'),
          buildFeatureBox(Icons.lock, 'How to Inactivate Account?'),
          buildFeatureBox(Icons.monetization_on, 'Tax Planning'),
        ],
      ),
    );
  }

  Widget buildFeatureBox(IconData icon, String title) {
    return Card(
      margin: EdgeInsets.all(8.0),
      child: InkWell(
        onTap: () {
          // Navigate to the respective section
        },
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Icon(icon, size: 50, color: Colors.red[800]),
              SizedBox(height: 10),
              Text(title, style: TextStyle(fontSize: 16)),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildTransactionTable() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('Recent Transactions', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columns: [
                DataColumn(label: Text('From Account')),
                DataColumn(label: Text('To Account')),
                DataColumn(label: Text('Recipient Account')),
                DataColumn(label: Text('Amount')),
                DataColumn(label: Text('Date & Time')),
              ],
              rows: transactions.map((transaction) {
                return DataRow(cells: [
                  DataCell(Text(transaction['fromAccount'].toUpperCase())),
                  DataCell(Text(transaction['toAccount'].toUpperCase())),
                  DataCell(Text(transaction['recipientAccount'].isEmpty ? 'N/A' : transaction['recipientAccount'])),
                  DataCell(Text('\$${transaction['amount'].toStringAsFixed(2)}')),
                  DataCell(Text(transaction['date'])),
                ]);
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildFooter(BuildContext context) {
    return Container(
      color: Colors.red[800],
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            'Quick Links',
            style: TextStyle(color: Colors.white, fontSize: 18),
          ),
          SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              TextButton(
                onPressed: () {},
                child: Text('About Us', style: TextStyle(color: Colors.white)),
              ),
              TextButton(
                onPressed: () {},
                child: Text('Contact Us', style: TextStyle(color: Colors.white)),
              ),
              TextButton(
                onPressed: () {},
                child: Text('Careers', style: TextStyle(color: Colors.white)),
              ),
              TextButton(
                onPressed: () {},
                child: Text('FAQs', style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
          SizedBox(height: 20),
          Divider(color: Colors.white),
          Text(
            '© 2024 Axis Bank. All rights reserved.',
            style: TextStyle(color: Colors.white),
          ),
        ],
      ),
    );
  }
}

class AccountsPage extends StatelessWidget {
  final Map<String, dynamic>? accountData;

  AccountsPage({this.accountData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Accounts'),
      ),
      body: accountData == null
          ? Center(child: CircularProgressIndicator())
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Chequing Account:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text('Account Number: ${accountData!['chequing']['accountNumber']}'),
            Text('Balance: \$${accountData!['chequing']['balance']} ${accountData!['chequing']['currency']}'),
            SizedBox(height: 20),
            Text('Savings Account:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text('Account Number: ${accountData!['savings']['accountNumber']}'),
            Text('Balance: \$${accountData!['savings']['balance']} ${accountData!['savings']['currency']}'),
          ],
        ),
      ),
    );
  }
}

class LoansPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Loans'),
      ),
      body: Center(
        child: Text('Loans Information goes here'),
      ),
    );
  }
}

class CardsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cards'),
      ),
      body: Center(
        child: Text('Cards Information goes here'),
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  final String email;

  ProfilePage({required this.email});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Name: $email', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            Text('Email: $email', style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Open Digital Account functionality not implemented yet.')),
                );
              },
              child: Text('Open Digital Account'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red[800],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
