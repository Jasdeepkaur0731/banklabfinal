package com.example.banklabfinal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
